package com.vlabs.test;
import com.vlabs.pageactions.*;
import com.vlabs.pageactions.Action_CartPage;
import com.vlabs.pageobjects.*;
import com.vlabs.utils.Util_AppData;
import com.vlabs.utils.Util_Device;
import com.vlabs.utils.Util_SetUp;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;


public class TC001_SignInTest_ValidCredentials extends Util_SetUp {
    
    public Action_SignInPage getSignInPage() {
        return new Action_SignInPage();
    }

    public Action_CommonPage getCommonPageActions() {
        return new Action_CommonPage();
    }
    public Util_Device getDeviceHelper() {
        return new Util_Device(driver);
    }

    
    @Test(description = "Sign in test - Valid Credentials")
    public void Test_ValidUserNamePassword() throws Exception {
        getDeviceHelper().startActivity(Util_AppData.appPackage, Util_AppData.appActivity);
        getSignInPage().signInwithValidCredentials(getCommonPageActions().getExcelData(Action_CommonPage.ExcelData.USER_ID),getCommonPageActions().getExcelData(Action_CommonPage.ExcelData.PASSWORD));
        getDeviceHelper().waitInSec(4);
        getDeviceHelper().reportLogging("Login Success");

          }
}