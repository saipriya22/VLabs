package com.vlabs.test;
import com.vlabs.pageactions.*;
import com.vlabs.pageactions.Action_CartPage;
import com.vlabs.pageobjects.*;
import com.vlabs.utils.Util_AppData;
import com.vlabs.utils.Util_Device;
import com.vlabs.utils.Util_SetUp;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;




public class TC002_SignInTest_UserIDEmpty extends Util_SetUp {
    
    public Action_SignInPage getSignInPage() {
        return new Action_SignInPage();
    }

    public Action_CommonPage getCommonPageActions() {
        return new Action_CommonPage();
    }
    public Util_Device getDeviceHelper() {
        return new Util_Device(driver);
    }

    
    @Test(description = "Sign in test - User ID Empty")
    public void Test_SignIn_EmptyUsername() throws Exception {
        getDeviceHelper().startActivity(Util_AppData.appPackage, Util_AppData.appActivity);
        getSignInPage().validateErrorMsgforUserId();
        getDeviceHelper().waitInSec(4);
        getDeviceHelper().reportLogging("Login Failed - Empty Username");
          }
}