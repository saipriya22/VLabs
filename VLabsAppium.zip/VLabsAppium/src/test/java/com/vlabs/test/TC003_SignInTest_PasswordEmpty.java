package com.vlabs.test;
import com.vlabs.pageactions.*;
import com.vlabs.pageactions.Action_CartPage;
import com.vlabs.pageobjects.*;
import com.vlabs.utils.Util_AppData;
import com.vlabs.utils.Util_Device;
import com.vlabs.utils.Util_SetUp;
import org.testng.annotations.Test;




public class TC003_SignInTest_PasswordEmpty extends Util_SetUp {
    
    public Action_SignInPage getSignInPage() {
        return new Action_SignInPage();
    }

    public Action_CommonPage getCommonPageActions() {
        return new Action_CommonPage();
    }
    public Util_Device getDeviceHelper() {
        return new Util_Device(driver);
    }

    
    @Test(description = "Sign in test - Password Empty")
    public void Test_SignIn_EmptyPassword() throws Exception {
        getDeviceHelper().startActivity(Util_AppData.appPackage, Util_AppData.appActivity);
        getSignInPage().validateErrorMsgforPassword(getCommonPageActions().getExcelData(Action_CommonPage.ExcelData.USER_ID));
        getDeviceHelper().waitInSec(4);
        getDeviceHelper().reportLogging("Login Failed - Empty Password");
          }
}