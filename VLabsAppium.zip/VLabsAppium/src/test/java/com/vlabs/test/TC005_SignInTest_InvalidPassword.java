package com.vlabs.test;
import com.vlabs.pageactions.*;
import com.vlabs.pageobjects.*;
import com.vlabs.utils.Util_AppData;
import com.vlabs.utils.Util_Device;
import com.vlabs.utils.Util_SetUp;
import org.testng.annotations.Test;




public class TC005_SignInTest_InvalidPassword extends Util_SetUp {
    
    public Action_SignInPage getSignInPage() {
        return new Action_SignInPage();
    }

    public Action_CommonPage getCommonPageActions() {
        return new Action_CommonPage();
    }
    public Util_Device getDeviceHelper() {
        return new Util_Device(driver);
    }

    
    @Test(description = "Sign in test - Invalid Password")
    public void Test_SignIn_InvalidPassowrd() throws Exception {
        getDeviceHelper().startActivity(Util_AppData.appPackage, Util_AppData.appActivity);
        getSignInPage().signInwithValidCredentials(getCommonPageActions().getExcelData(Action_CommonPage.ExcelData.USER_ID),getCommonPageActions().getExcelData(Action_CommonPage.ExcelData.INVALID_PASSWORD));
        getDeviceHelper().waitInSec(4);
        getDeviceHelper().reportLogging("Login Failed - Invalid Password");
          }
}