package com.vlabs.test;
import com.vlabs.pageactions.*;
import com.vlabs.pageactions.Action_CartPage;
import com.vlabs.pageobjects.*;
import com.vlabs.utils.Util_AppData;
import com.vlabs.utils.Util_Device;
import com.vlabs.utils.Util_SetUp;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;


public class TC006_SignInTest_OrderProcessing extends Util_SetUp {
    
    public Action_SignInPage getSignInPage() {
        return new Action_SignInPage();
    }

    public Action_HomePage getHomePage() {
        return new Action_HomePage();
    }

    public Action_CartPage getCartPage() {
        return new Action_CartPage();
    }
    
    public Action_CheckOutPage getCheckOutPage() {
        return new Action_CheckOutPage();
    }
   
    public Page_Home getHome() {
        return new Page_Home();
    }

    public Action_CommonPage getCommonPageActions() {
        return new Action_CommonPage();
    }
    public Util_Device getDeviceHelper() {
        return new Util_Device(driver);
    }

    
    @Test(description = "OrderProcessing Test")
    public void Test_OrderProcessing() throws Exception {
        getDeviceHelper().startActivity(Util_AppData.appPackage, Util_AppData.appActivity);
        getSignInPage().signInwithValidCredentials(getCommonPageActions().getExcelData(Action_CommonPage.ExcelData.USER_ID),getCommonPageActions().getExcelData(Action_CommonPage.ExcelData.PASSWORD));
        getDeviceHelper().waitInSec(4);
        getDeviceHelper().reportLogging("Login Success");
        getHomePage().addItemsToCart(getCommonPageActions().getExcelData(Action_CommonPage.ExcelData.Product1));
        getHomePage().addItemsToCart(getCommonPageActions().getExcelData(Action_CommonPage.ExcelData.Product2));
        getHomePage().addItemsToCart(getCommonPageActions().getExcelData(Action_CommonPage.ExcelData.Product3));
        getHomePage().clickOnCart();
        getCartPage().clickRemoveBtn();
        getCartPage().clickOnCheckOutBtn();
        getDeviceHelper().reportLogging("Checkout Page");
        getCheckOutPage().enterDetails(getCommonPageActions().getExcelData(Action_CommonPage.ExcelData.FIRST_NAME),getCommonPageActions().getExcelData(Action_CommonPage.ExcelData.LAST_NAME),"602024");
        getCheckOutPage().clickOnContinueBtn();
        getCheckOutPage().getDeliveryAndPaymentDetails();
        getCheckOutPage().clickOnFinish();
        getDeviceHelper().reportLogging("Order Completed");    
        getCheckOutPage().clickOnBackToHome();
        getHomePage().clickOnLogout();
          }
}