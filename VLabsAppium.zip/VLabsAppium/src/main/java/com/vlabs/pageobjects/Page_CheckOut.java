package com.vlabs.pageobjects;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class Page_CheckOut {

	@AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"test-First Name\"]")
    public MobileElement firstNameField;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"test-Last Name\"]")
    public MobileElement lastNameField;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[contains(@content-desc,\"Postal Code\")]")
    public MobileElement pincodeField;
	
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"test-CONTINUE\"]")
    public MobileElement continueBtn;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Payment Information:\"]//following::android.widget.TextView[1]")
    public MobileElement paymentrefNom;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Shipping Information:\"]//following::android.widget.TextView[1]")
    public MobileElement shippingInformation;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,\"Total\")]")
    public MobileElement totalAmount;

	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"test-FINISH\"]")
    public MobileElement finshBtn;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@text=\"THANK YOU FOR YOU ORDER\"]")
    public MobileElement thankYouLabel;
	
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"test-BACK HOME\"]")
    public MobileElement backtoHomebtn;
	
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"test-CANCEL\"]")
    public MobileElement cancelBtn;
	}
