package com.vlabs.pageobjects;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidBy;
import io.appium.java_client.pagefactory.AndroidFindAll;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class Page_SignIn {

	@AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"test-Username\"]")
    public MobileElement fieldUserID;

    @AndroidFindBy(xpath = "//android.widget.EditText[@content-desc=\"test-Password\"]")
    public MobileElement fieldPassword;

    @AndroidFindAll({
            @AndroidBy(xpath = "//android.widget.EditText[@text=\"Enter your password\"]"),
            @AndroidBy(xpath = "//android.widget.EditText[@text=\"•••••••\"]"),
            @AndroidBy(xpath = "//android.widget.EditText[@text=\"••••••••\"]"),
            @AndroidBy(xpath = "//android.widget.EditText[@text=\"••••••••••\"]")
    })
    public MobileElement fieldPwd;
    
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Username is required\"]")
    public MobileElement errorMsgForUserID;
        
    @AndroidFindAll({
        @AndroidBy(xpath = "//android.widget.TextView[@text=\"Password is required\"]"),
    })
    public MobileElement errorMsgForPwd;

    @AndroidFindAll({
        @AndroidBy(xpath = "//android.widget.TextView[@text=\"Username and password do not match any user in this service.\"]"),
    })
    public MobileElement errorMsgForInvalidcredentials;

    
    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"test-LOGIN\"]")
    public MobileElement loginBtn;

}
