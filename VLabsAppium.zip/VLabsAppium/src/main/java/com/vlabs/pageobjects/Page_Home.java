package com.vlabs.pageobjects;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidBy;
import io.appium.java_client.pagefactory.AndroidFindAll;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class Page_Home {

	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"test-Menu\"]")
    public MobileElement menuIcon;
	
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"test-Cart\"]")
    public MobileElement cartIcon;
	
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"test-Cart\"]//child::android.view.ViewGroup//child::android.widget.TextView")
    public MobileElement noofIteminCart;
	
	@AndroidFindAll ({
		@AndroidBy(xpath = "//android.widget.TextView[@text=\"PRODUCTS\"]"),
		@AndroidBy(xpath = "//android.view.ViewGroup[@content-desc=\"test-Cart drop zone\"]//following::android.widget.TextView[1]"),
	})
    public MobileElement procductsLabel;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@text=\"PRODUCTS\"]//following-sibling::android.view.ViewGroup[1]")
    public MobileElement itemsViewBtn;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@text=\"PRODUCTS\"]//following-sibling::android.view.ViewGroup[2]")
    public MobileElement filterBtn;
	
	@AndroidFindAll ({
		@AndroidBy(xpath = "//android.widget.TextView[@text=\"LOGOUT\"]"),
		@AndroidBy(xpath = "//android.view.ViewGroup[@text=\"test0-LOGOUT\"]"),
	})
    public MobileElement logout;

    }
