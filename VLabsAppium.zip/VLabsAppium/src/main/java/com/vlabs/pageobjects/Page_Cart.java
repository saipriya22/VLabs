package com.vlabs.pageobjects;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class Page_Cart {

	@AndroidFindBy(xpath = "//android.widget.TextView[@text=\"YOUR CART\"]")
    public MobileElement yourCartLabel;
	
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"test-CONTINUE SHOPPING\"]")
    public MobileElement continueShoppingBtn;
	
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"test-CHECKOUT\"]")
    public MobileElement checkoutBtn;
	
	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"test-Item\"]")
    public MobileElement item;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@text=\"PRODUCTS\"]")
    public MobileElement procductsLabel;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@text=\"PRODUCTS\"]//following-sibling::android.view.ViewGroup[1]")
    public MobileElement itemsViewBtn;

	@AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"test-REMOVE\"]")
    public MobileElement removeBtn;
	
	@AndroidFindBy(xpath = "//android.widget.EditText[@text=\"PRODUCTS\"]//following-sibling::android.view.ViewGroup[2]")
    public MobileElement filterBtn;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@text=\"LOGOUT\"]")
    public MobileElement logout;


}
