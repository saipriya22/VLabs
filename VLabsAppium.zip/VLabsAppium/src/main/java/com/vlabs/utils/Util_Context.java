package com.vlabs.utils;

import io.appium.java_client.AppiumDriver;

/**
 *
 * Purpose:	To set the configuration for type of drivers
 */

public class Util_Context {

    private static ThreadLocal<AppiumDriver> webDriver = new ThreadLocal<>();

    public static AppiumDriver getDriver() {
        return webDriver.get();
    }

    public static void setDriver(AppiumDriver driver) {
        webDriver.set(driver);
    }
}

