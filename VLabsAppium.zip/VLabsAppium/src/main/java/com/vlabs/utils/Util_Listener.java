package com.vlabs.utils;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;

import com.vlabs.reports.ExtentReport;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Iterator;

/**
 * Purpose:	Test Utilities and Listeners
 */

public class Util_Listener extends Util_TestSetUp implements ITestListener {

    public static ExtentReport extentTestFactory;

    public Util_Listener() {
        extentTestFactory = new ExtentReport();
    }

    @Override
    public void onStart(ITestContext iTestContext) {
    }

    @Override
    public void onFinish(ITestContext iTestContext) {
        Iterator<ITestResult> skippedTestCases = iTestContext.getSkippedTests().getAllResults().iterator();
        while (skippedTestCases.hasNext()) {
            ITestResult skippedTestCase = skippedTestCases.next();
            ITestNGMethod method = skippedTestCase.getMethod();
            if (iTestContext.getSkippedTests().getResults(method).size() > 0) {
                System.out.println("Removing:" + skippedTestCase.getTestClass().toString());
                skippedTestCases.remove();
            }
        }
    }

    @Override
    public void onTestStart(ITestResult iTestResult) {
//        String methodName = iTestResult.getMethod().getMethodName();
//        String className = iTestResult.getTestClass().getName().substring(iTestResult.getTestClass().getName().indexOf(".") + 1);
//        DataFactory dataTable = new DataFactory(System.getProperty("user.dir") + "\\DataTables", className);
//        dataTable.setCurrentRow(methodName);
    }

    @Override
    public void onTestSuccess(ITestResult iTestResult) {
    }

    @Override
    public void onTestFailure(ITestResult iTestResult) {
    }

    @Override
    public void onTestSkipped(ITestResult iTestResult) {
        if (iTestResult.getThrowable().getMessage().contains("Skipped By retry")) {
            ExtentReport.getExtentTest().getExtent().removeTest(ExtentReport.getExtentTest());
        } else {
            StringWriter exceptionInfo = new StringWriter();
            iTestResult.getThrowable().printStackTrace(new PrintWriter(exceptionInfo));
            String methodClassName = iTestResult.getThrowable().getMessage();
            for (StackTraceElement stack : iTestResult.getThrowable().getStackTrace()) {
                if (stack.getClassName().contains("co.bpcl.pages.Actions")) {
                    methodClassName = methodClassName + "   Failed in Class: " + stack.getClassName() +
                            ",  in Method : " + stack.getMethodName() +
                            ",  and Line : " + stack.getLineNumber() + " This test case will be rerun, Since it failed in the first attempt";
                    break;
                }
            }

            ExtentReport.getExtentTest().skip(methodClassName);
            ExtentReport.getExtentTest().addScreenCaptureFromBase64String(takeScreenShot());

        }

    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult iTestResult) {
    }
}