package com.vlabs.utils;

public interface Util_AppData {
    String sheetName = "TestData";
    String appPackage = "com.swaglabsmobileapp";
    String appActivity = "com.swaglabsmobileapp.MainActivity";
    
}