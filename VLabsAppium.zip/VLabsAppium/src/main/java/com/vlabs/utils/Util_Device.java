package com.vlabs.utils;

import com.aventstack.extentreports.ExtentTest;
import com.github.javafaker.Faker;
import com.vlabs.reports.ExtentReport;
import com.vlabs.reports.ExtentTestFactoryParent;


import io.appium.java_client.*;
import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.clipboard.HasClipboard;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;
import java.util.List;
import java.util.Random;

import static io.appium.java_client.touch.LongPressOptions.longPressOptions;
import static io.appium.java_client.touch.WaitOptions.waitOptions;
import static io.appium.java_client.touch.offset.ElementOption.element;
import static io.appium.java_client.touch.offset.PointOption.point;
import static java.time.Duration.ofSeconds;

/**
 * Generic Methods
 */
public class Util_Device {

    public AppiumDriver driver;
    WebDriverWait wait = null;
    int counter = 0;

    public Util_Device(AppiumDriver driver) {
        this.driver = driver;
    }

   
    /**
     * This Function is to check the element is present or not
     */
    public boolean isElementDisplayed(MobileElement locator) {
        try {
            if (locator.isDisplayed())
                ;
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }

       /**
     * This Function will pause the execution for given secs.
     *
     * @param secs : No of seconds to be paused.
     */
    public void waitInSec(int secs) {
        try {
            Thread.sleep(secs * 1000);

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * @param locator : By Locator of the element
     * @return true if element is displayed. Otherwise false.
     * @author
     */
    public boolean isDisplayed(MobileElement locator) {
        return locator.isDisplayed();
    }
    /**
     * Perform swipe action vertically from point X to point Y on any screen
     */
    public void swipeUp() {
        Dimension size = driver.manage().window().getSize();
        int starty = (int) (size.height * 0.85);
        int endy = (int) (size.height * 0.2);
        int startx = (int) (size.width / 2.2);
        try {
            new TouchAction(driver).press(point(startx, starty)).waitAction(waitOptions(ofSeconds(2)))
                    .moveTo(point(startx, endy)).release().perform();
            reportLogging("Swipe up");
        } catch (Exception e) {
        }
    }

    /**
     * This Function is to Scroll to element
     */
    public void scrollToMobileElement(MobileElement element, String scrollCount, String info) {
        try {
            int count = Integer.parseInt(scrollCount);
            for (int i = 0; i < count; i++) {
                if (isElementDisplayed(element)) {
                    break;
                } else {
                    reportLogging(info);
                    swipeUp();
                }
            }
        } catch (Exception e) {
        }
    }

    public void scrollDownToMobileElement(MobileElement element, String scrollCount) {
        try {
            int count = Integer.parseInt(scrollCount);
            for (int i = 0; i < count; i++) {

                if (isElementPresent(element)) {
                    break;
                } else {
                    swipeDown();
                }

            }
        } catch (Exception e) {
        }
    }



    public void startActivity(String appPackage, String appActivity) {
        ((AndroidDriver) driver).startActivity(new Activity(appPackage, appActivity));
    }

    /**
     * This Function is to report log's in execution reports
     */
    public void reportLogging(String info) {
        try {
            ExtentTest loggerReport = ExtentReport.getExtentTest();
            loggerReport.info(info);

        } catch (NullPointerException e) {
            reportClassLogging(info);
        }
    }
    
    /**
     * This Function is to report log's in execution reports
     */
    public void reportClassLogging(String info) {
        ExtentTest loggerReport = ExtentTestFactoryParent.getExtentTest();
        loggerReport.info(info);
    }


    /**
     * This Function is to check the element is present or not after explicit waiting of the element.
     */
    public boolean isElementPresent(MobileElement locator) {
        try {
            waitForElementToAppear(locator, "");
            if (locator.isDisplayed()) ;
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    public MobileElement waitForElementToAppear(MobileElement id, String info) {
        reportLogging(info);
        WebDriverWait wait = new WebDriverWait(driver, 5);
        wait.until(ExpectedConditions.visibilityOf(id));
        return id;
    }



    /**
     * This Function is to swipe Down or Refresh the screen
     */
    public void swipeDown() {
        Dimension size = driver.manage().window().getSize();
        int starty = (int) (size.height * 0.45);
        int endy = (int) (size.height * 0.90);
        int startx = (int) (size.width / 2.2);
        try {
            new TouchAction((PerformsTouchActions) driver).press(point(startx, starty)).waitAction(waitOptions(ofSeconds(3)))
                    .moveTo(point(startx, endy)).release().perform();
            reportLogging("Swipe Down");
        } catch (Exception e) {
        }
    }

   
    /**
     * This Function is to check element is not present and return true or false
     */
    public boolean isElementNotPresent(MobileElement element) {
        if (isElementDisplayed(element) == false) {
            return true;
        } else {
            return false;
        }
    }

       /**
     * This function is to add fail info to validation tests
     */
    public void reportLoggingFail(String info) {
        ExtentTest loggerReport = ExtentReport.getExtentTest();
        loggerReport.fail(info);
    }

   

    /**
     * This function will wait for the element to be visible and clickable and then clicks on it
     */
    public void waitAndClick(MobileElement element, String info) {
        waitTillTheElementIsVisibleAndClickable(element);
        element.click();
        reportLogging(info);
    }
    
    public void waitTillTheElementIsVisibleAndClickable(MobileElement element) {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOf(element));
        wait = new WebDriverWait(driver, 3);
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }


    /**
     * This function is to log report agit and to be used in case of validations in a test case.
     *
     * @param flag     return a boolean if the test case meets or does not meet the validation condition
     * @param info     Pass the validation info when expected condition met
     * @param failInfo Pass the fail validation info when expected condition is not met
     */
    public void reportLoggingForValidation(boolean flag, String info, String failInfo) {
        ExtentTest loggerReport = ExtentReport.getExtentTest();
        if (flag) {
            loggerReport.info(info);
            Assert.assertTrue(flag, failInfo);

        } else {
            loggerReport.fail(failInfo);

        }
    }

    public String getText(MobileElement element) {
        scrollToMobileElement(element, "3", "");
        //waitForElementToAppear(element,"");
        String elementText = element.getText();
        return elementText;
    }

   
    /**
     * Perform swipe action vertically from point X to point Y on any screen
     */
    public void swipeUp(double heightValue) {
        Dimension size = driver.manage().window().getSize();
        int starty = (int) (size.height * heightValue);
        int endy = (int) (size.height * 0.2);
        int startx = (int) (size.width / 2.2);
        try {
            new TouchAction((PerformsTouchActions) driver).press(point(startx, starty)).waitAction(waitOptions(ofSeconds(2)))
                    .moveTo(point(startx, endy)).release().perform();
            reportLogging("Swipe up");
        } catch (Exception e) {
        }
    }

    
    public void inputText(MobileElement element, String input) {
        scrollToMobileElement(element, "3", "");
        //waitForElementToAppear(element, "");
        element.clear();
        reportLogging("Select : " + input);
        element.sendKeys(input);
    }

    public boolean containsIgnoreCase(String str, String searchStr) {
        if (str == null || searchStr == null) {
            return false;
        } else {
            int len = searchStr.length();
            int max = str.length() - len;
            for (int i = 0; i <= max; i++) {
                if (str.regionMatches(true, i, searchStr, 0, len)) {
                    return true;
                }
            }
        }

        return false;
    }

    
    public MobileElement findElementByScroll(String query) {
        try {
            MobileElement date = (MobileElement) driver.findElement(MobileBy.AndroidUIAutomator(query));
            return date;
        } catch (NoSuchElementException e) {
            return null;
        }
    }

    
}

