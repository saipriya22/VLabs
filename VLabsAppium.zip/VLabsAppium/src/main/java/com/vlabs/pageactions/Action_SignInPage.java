package com.vlabs.pageactions;

import org.testng.Assert;

import com.vlabs.pageobjects.*;
import com.vlabs.utils.Util_AppData;
import com.vlabs.utils.Util_Context;
import com.vlabs.utils.Util_Device;
import com.vlabs.utils.Util_Listener;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class Action_SignInPage extends Util_Listener {
    Util_Device deviceHelper;
    Page_SignIn signInScreen = new Page_SignIn();
    

    Action_CommonPage commonPageActions;
    AppiumDriver driver;

    public Action_SignInPage() {
        this.driver = Util_Context.getDriver();
        deviceHelper = new Util_Device(driver);
        commonPageActions = new Action_CommonPage();
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
        PageFactory.initElements(new AppiumFieldDecorator(driver), signInScreen);
    }

    public void signInwithValidCredentials(String name, String password) throws Exception {
        deviceHelper.inputText(signInScreen.fieldUserID, name);
        deviceHelper.inputText(signInScreen.fieldPassword, password);
        deviceHelper.waitAndClick(signInScreen.loginBtn, "Login button is tapped");
        deviceHelper.waitInSec(2);
//        Assert.assertTrue(deviceHelper.isElementPresent(businessProgramsPageObjects.continueToReg), "Business program page is displayed");
//        deviceHelper.reportLogging("Business program Page is displayed");
    }

        public void validateErrorMsgforUserId() throws IOException {
        deviceHelper.waitAndClick(signInScreen.loginBtn, "Login button is tapped");
        Assert.assertTrue(deviceHelper.getText(signInScreen.errorMsgForUserID).contains("Username is required"), "Error message is displayed");
        deviceHelper.reportLogging("Error : User ID is required");
    }
    
    public void validateErrorMsgforPassword(String validUserID) throws IOException {
        deviceHelper.inputText(signInScreen.fieldUserID, validUserID);
         deviceHelper.waitAndClick(signInScreen.loginBtn, "Login button is tapped");
         Assert.assertTrue(deviceHelper.getText(signInScreen.errorMsgForPwd).contains("Password is required"), "Error message is displayed");
         deviceHelper.reportLogging("Error : Password is required");
     }

    public void validateErrorMsgWithWrongUserIdandPwd(String userId,String pwd) throws IOException {
    	deviceHelper.inputText(signInScreen.fieldUserID, userId);
    	deviceHelper.inputText(signInScreen.fieldPassword, pwd);    	
        deviceHelper.waitAndClick(signInScreen.loginBtn, "Login button is tapped");
        Assert.assertTrue(deviceHelper.getText(signInScreen.errorMsgForInvalidcredentials).contains("Username and password do not match any user in this service"), "Error message is displayed");
        deviceHelper.reportLogging("Error : Username and password do not match any user in this service");
    }

    
}
