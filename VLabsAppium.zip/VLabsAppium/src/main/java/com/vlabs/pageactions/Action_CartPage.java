package com.vlabs.pageactions;

import java.io.IOException;
import java.util.List;



import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;

import com.vlabs.pageobjects.Page_Cart;
import com.vlabs.pageobjects.Page_Home;
import com.vlabs.utils.Util_Context;
import com.vlabs.utils.Util_Device;
import com.vlabs.utils.Util_Listener;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class Action_CartPage extends Util_Listener {
    Util_Device deviceHelper;
    Page_Home homeScreen = new Page_Home();
    Page_Cart cartScreen = new Page_Cart();
	
    

    Action_CommonPage commonPageActions;
    AppiumDriver driver;

    public Action_CartPage() {
        this.driver = Util_Context.getDriver();
        deviceHelper = new Util_Device(driver);
        commonPageActions = new Action_CommonPage();
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
        PageFactory.initElements(new AppiumFieldDecorator(driver), cartScreen);
        PageFactory.initElements(new AppiumFieldDecorator(driver), homeScreen);
    }

    public void clickOnCheckOutBtn() throws Exception {
    	deviceHelper.scrollToMobileElement(cartScreen.checkoutBtn, "3", "");
        deviceHelper.waitAndClick(cartScreen.checkoutBtn, "Click On CheckOut");
    }
    
    public void clickOnContinueShopping() throws Exception {
    	deviceHelper.scrollToMobileElement(cartScreen.continueShoppingBtn, "3", "");
        deviceHelper.waitAndClick(cartScreen.continueShoppingBtn, "Click On Continue Shopping");
    }
        
    public void clickRemoveBtn() throws Exception{
    	deviceHelper.waitAndClick(cartScreen.removeBtn, "Removing Item");
    }
    
}
