package com.vlabs.pageactions;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;

import com.vlabs.pageobjects.Page_Cart;
import com.vlabs.pageobjects.Page_CheckOut;
import com.vlabs.pageobjects.Page_Home;
import com.vlabs.utils.Util_Context;
import com.vlabs.utils.Util_Device;
import com.vlabs.utils.Util_Listener;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class Action_CheckOutPage extends Util_Listener {
    Util_Device deviceHelper;
    Page_CheckOut checkOutScreen = new Page_CheckOut();
    

    Action_CommonPage commonPageActions;
    AppiumDriver driver;

    public Action_CheckOutPage() {
        this.driver = Util_Context.getDriver();
        deviceHelper = new Util_Device(driver);
        commonPageActions = new Action_CommonPage();
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
        PageFactory.initElements(new AppiumFieldDecorator(driver), checkOutScreen);
    }

    public void clickOnContinueBtn() throws Exception {
    	deviceHelper.scrollToMobileElement(checkOutScreen.continueBtn,"3","");
        deviceHelper.waitAndClick(checkOutScreen.continueBtn, "Click On Continue");
    }
    
    public void clickOnCancelBtn() throws Exception {
    	deviceHelper.scrollToMobileElement(checkOutScreen.cancelBtn,"3","");
        deviceHelper.waitAndClick(checkOutScreen.cancelBtn, "Click On Cancel");
    }
    
   public void enterDetails(String fullname,String lastname,String pincode) throws Exception{
	   deviceHelper.inputText(checkOutScreen.firstNameField, fullname);
	   deviceHelper.inputText(checkOutScreen.lastNameField, lastname);
	   deviceHelper.inputText(checkOutScreen.pincodeField, pincode);
   }
   
   public void getDeliveryAndPaymentDetails() throws Exception {
	   deviceHelper.scrollToMobileElement(checkOutScreen.paymentrefNom,"3","");
	   deviceHelper.reportLogging("Payment Informatiobn"+deviceHelper.getText(checkOutScreen.paymentrefNom));
	   deviceHelper.scrollToMobileElement(checkOutScreen.shippingInformation,"3","");
	   deviceHelper.reportLogging("ShippingInformation"+deviceHelper.getText(checkOutScreen.shippingInformation));
	   deviceHelper.scrollToMobileElement(checkOutScreen.totalAmount,"3","");
	   deviceHelper.reportLogging("totalAmount"+deviceHelper.getText(checkOutScreen.totalAmount).substring(deviceHelper.getText(checkOutScreen.totalAmount).indexOf(":")+1));
   }
   
   public void clickOnFinish() {
	   deviceHelper.scrollToMobileElement(checkOutScreen.finshBtn,"3","");
	   deviceHelper.waitAndClick(checkOutScreen.finshBtn, "click on finish");
   }
   public void clickOnBackToHome() {
	   deviceHelper.scrollToMobileElement(checkOutScreen.backtoHomebtn,"3","");
	   deviceHelper.waitAndClick(checkOutScreen.backtoHomebtn, "click on Back to Home");
   }   
}