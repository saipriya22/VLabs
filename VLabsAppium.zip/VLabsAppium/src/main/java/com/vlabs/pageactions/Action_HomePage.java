package com.vlabs.pageactions;

import java.io.IOException;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.vlabs.pageobjects.Page_Home;
import com.vlabs.pageobjects.Page_SignIn;
import com.vlabs.utils.Util_Context;
import com.vlabs.utils.Util_Device;
import com.vlabs.utils.Util_Listener;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class Action_HomePage extends Util_Listener {
    Util_Device deviceHelper;
    Page_Home homeScreen = new Page_Home();
    

    Action_CommonPage commonPageActions;
    AppiumDriver driver;

    public Action_HomePage() {
        this.driver = Util_Context.getDriver();
        deviceHelper = new Util_Device(driver);
        commonPageActions = new Action_CommonPage();
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
        PageFactory.initElements(new AppiumFieldDecorator(driver), homeScreen);
    }

    public void clickOnFilter() throws Exception {
        deviceHelper.waitAndClick(homeScreen.filterBtn, "Click On Filter");
    }
    
    public void clickOnMenu() throws Exception {
        deviceHelper.waitAndClick(homeScreen.menuIcon, "Click On Menu");
    }
    
    public void clickOnItemView() throws Exception {
        deviceHelper.waitAndClick(homeScreen.itemsViewBtn, "Click On Items View");
    }
    
    public void clickOnCart() throws Exception {
        deviceHelper.waitAndClick(homeScreen.cartIcon, "Click On Cart");
    }
    
    public void clickOnLogout() throws Exception {
        deviceHelper.waitAndClick(homeScreen.menuIcon, "Click On Menu");
        //deviceHelper.wait(4);
        deviceHelper.waitAndClick(homeScreen.logout, "Click On Logout");
    }
    
    public void noofItemsinCart() throws IOException {
    	if (deviceHelper.isElementPresent(homeScreen.noofIteminCart) ) {
    	deviceHelper.reportLogging("No.of Items added to cart:"+deviceHelper.getText(homeScreen.noofIteminCart));
    }
    	else{
    	deviceHelper.reportLogging("No items are added to Cart");
    	}
    }

    public void addItemsToCart(String itemName) throws Exception {
    	String query="new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\""+itemName+"\").instance(0).fromParent(new UiSelector().description(\"test-ADD TO CART\")))";
    	MobileElement ele=deviceHelper.findElementByScroll(query);
//    	MobileElement ele1=(MobileElement) driver.findElementByXPath("//android.widget.TextView[@text='"+itemName+"']//following-sibling::android.view.ViewGroup[@content-desc='test-ADD TO CART']");
    	deviceHelper.scrollToMobileElement(ele, "3", "");
    	deviceHelper.waitAndClick(ele, "Click on Add to Cart button");
        deviceHelper.reportLogging("Item is add to Cart is:"+itemName);
    }
    
     public void addItemsToCart1(String itemName)throws Exception {
    	 String query="new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\""+itemName+"\").instance(0))";
    	 MobileElement ele=deviceHelper.findElementByScroll(query);
    	 deviceHelper.waitAndClick(ele, "click on ele");
     }
     
     
}
