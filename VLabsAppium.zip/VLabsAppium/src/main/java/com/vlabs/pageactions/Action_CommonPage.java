package com.vlabs.pageactions;

import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.vlabs.config.Config;
import com.vlabs.pageobjects.*;
import com.vlabs.utils.Util_AppData;
import com.vlabs.utils.Util_Context;
import com.vlabs.utils.Util_Device;
import com.vlabs.utils.Util_Listener;

import io.appium.java_client.AppiumDriver;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.IOException;

/**
 * This Class has all the actions common to all pages
 */
public class Action_CommonPage extends Util_Listener implements Util_AppData {

    Util_Device deviceHelper;
    AppiumDriver driver;
    public Config prop;
    Page_SignIn signInScreenPageObjects = new Page_SignIn();
    

    public Action_CommonPage() {
        this.driver = Util_Context.getDriver();
        deviceHelper = new Util_Device(driver);
        
        PageFactory.initElements(new AppiumFieldDecorator(driver), signInScreenPageObjects);
    }

    
    

    public void openBrowser() {
        deviceHelper.startActivity("com.android.chrome",
                "com.google.android.apps.chrome.Main");
        deviceHelper.reportLogging("Goto Browser Window");
    }

    public void openApp(String appPackage, String appActivity) {
        deviceHelper.startActivity(appPackage, appActivity);
        deviceHelper.reportLogging("Goto App Window");
    }

   

    
    public enum ExcelData {
        USER_ID,
        PASSWORD,
        INVALID_PASSWORD,
        Product1,
        Product2,
        Product3,
        FIRST_NAME,
        LAST_NAME,
        PINCODE,
        INVALID_USER_ID,
           }

    public String getExcelData(ExcelData excelData) throws IOException {
        String value = "";
        switch (excelData) {
            case USER_ID:
                value = getCellData(sheetName, 1, 1);
                //deviceHelper.reportLogging("Getting username");
                break;
            case PASSWORD:
                value = getCellData(sheetName, 1, 2);
                //deviceHelper.reportLogging("Getting password");
                break;
            case INVALID_USER_ID:
                value = getCellData(sheetName, 1, 3);
                //deviceHelper.reportLogging("Getting invalid password");
                break;
            case INVALID_PASSWORD:
                value = getCellData(sheetName, 1, 4);
                //deviceHelper.reportLogging("Getting invalid password");
                break;
           case FIRST_NAME:
                value = getCellData(sheetName, 1, 8);
                //deviceHelper.reportLogging("Getting First Name");
                break;
            case LAST_NAME:
                value = getCellData(sheetName, 1, 9);
                //deviceHelper.reportLogging("Getting Last Name");
                break;
           
            case PINCODE:
                value = getCellData(sheetName, 1, 10);
                //deviceHelper.reportLogging("Getting Pincode");
                break;
            case Product1:
                value = getCellData(sheetName, 1, 5);
                //deviceHelper.reportLogging("Getting OTP");
                break;
            case Product2:
                value = getCellData(sheetName, 1, 6);
                //deviceHelper.reportLogging("Getting OTP");
                break;
            case Product3:
                value = getCellData(sheetName, 1, 7);
                //deviceHelper.reportLogging("Getting OTP");
                break;
                }
        return value;
    }


    public String getCellData(String sheetName, int columnNum, int rowNum) throws IOException {
        prop = Config.getInstance();
        FileInputStream fis = new FileInputStream(System.getProperty("user.dir") + "/" + prop.getProperty("excelPath"));
        System.out.println("Path :" + fis);
        XSSFWorkbook workbook = new XSSFWorkbook(fis);
        XSSFSheet sheet = workbook.getSheet(sheetName);
        //Row row = sheet.getRow(rowNum);
        DataFormatter formatter = new DataFormatter();
        String val = formatter.formatCellValue(sheet.getRow(rowNum).getCell(columnNum));
        //Cell cell = row.getCell(columnNum);
        //String value = cell.getStringCellValue();
        //System.out.println("Value:" +value);
        return val;
    }
}
